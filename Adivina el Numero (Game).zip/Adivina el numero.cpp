#include <iostream>
#include <cstdlib>
#include <ctime>
#include <windows.h>
#include "Biblotecas\JASG\JASG.h"

using namespace std;

const char* Musica_Fondo = "ME/Mios/Musica/Menu depresivo.wav";
const char* Musica_Effect_Error = "ME/Mios/Efectos/Error.wav";
const char* Musica_Effect_Win = "ME/Mios/Efectos/win.wav";
const char* Musica_Effect_Correct = "ME/Mios/Efectos/Correct.wav";

// Variables Globales
int Vidas = 0;
int NR;
int Fallos;
string DF;
int Vict = 0;

int GeN(int dificulty);
int MenuD();
void Game();
void Victoria();
void DERROTA();
void Menu();

int main() {
    Window("full", "white", "red");
    Menu();
    return 0;
}

int MenuD() {
    int option;

    while (true) {
        cout << c("     _______. _______  __       _______   ______ .___________.  ______   .______          _______   _______     _______   __   _______  __    ______  __    __   __      .___________.     ___       _______  ") << endl;
        cout << c("    /       ||   ____||  |     |   ____| /      ||           | /  __  \\  |   _  \\        |       \\ |   ____|   |       \\ |  | |   ____||  |  /      ||  |  |  | |  |     |           |    /   \\     |       \\ ") << endl;
        cout << c("   |   (----`|  |__   |  |     |  |__   |  ,----'`---|  |----`|  |  |  | |  |_)  |       |  .--.  ||  |__      |  .--.  ||  | |  |__   |  | |  ,----'|  |  |  | |  |     `---|  |----`   /  ^  \\    |  .--.  |") << endl;
        cout << c("    \\   \\    |   __|  |  |     |   __|  |  |         |  |     |  |  |  | |      /        |  |  |  ||   __|     |  |  |  ||  | |   __|  |  | |  |     |  |  |  | |  |         |  |       /  /_\\  \\   |  |  |  |") << endl;
        cout << c(".----)   |   |  |____ |  `----.|  |____ |  `----.    |  |     |  `--'  | |  |\\  \\----.   |  '--'  ||  |____    |  '--'  ||  | |  |     |  | |  `----.|  `--'  | |  `----.    |  |      /  _____  \\  |  '--'  |") << endl;
        cout << c("|_______/    |_______||_______||_______| \\______|    |__|      \\______/  | _| `._____|   |_______/ |_______|   |_______/ |__| |__|     |__|  \\______| \\______/  |_______|    |__|     /__/     \\__\\ |_______/ ") << endls(3);
        cout << c("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------") << endl;
        cout << endl;
        cout << "		1.Facil" << endl << endl;
        cout << "		2.Intermedio" << endl << endl;
        cout << "		3.Imposible" << endl << endl;
        cout << c("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------") << endl;
        cout << endl << endl << "		> ";
        cin >> option;

        switch (option) {
            case 1:
            case 2:
            case 3:
                return option;
            default:
                system("cls");
                SoundInter(Musica_Effect_Error,Musica_Fondo,1000);
                msg("Eso no es una opcion", "error");
        }
    }
}

void Game() {
    Fallos = 0;
    Vidas = 0;

    int D = MenuD();  // Obtiene la dificultad
    int N = GeN(D);   // Genera el n�mero a adivinar

    system("cls");

    do {
        system("cls");
        int I;  // Variable para guardar la entrada del usuario
        cout << endl << c("ADEVINA EL NUMERO") << endl;
        cout << c("---------------------------") << endl;
        cout << endls(2);

        cout << "        VIDAS: " << Vidas << endl;
        cout << "        DIFICULTAD: " << D << endl; // Cambiado de DF a D
        cout << "        FALLOS: " << Fallos << endls(3);

        cout << "        > ";
        cin >> I;  // Entrada del usuario

        if (I == NR) {  // Compara con el n�mero generado
            Victoria();  // Funci�n para manejar la victoria
            break;
        } else {
        	system("cls");
            cout << endl << c("INCORRECTO: -1 Vida");
            Vidas -= 1;  // Resta una vida
            Fallos += 1; // Aumenta el contador de fallos
            cout << endl << "        Presiona SPACE para continuar..";
            needs("space");  
        }
    } while (Vidas > 0);  // Aseg�rate de que se termine cuando Vidas sea 0

    DERROTA();  // Funci�n para manejar la derrota
}


void Menu(){
	playSound(Musica_Fondo);
	while (true){
		int I;
		system("cls");
		cout << endl << c("-----------------------------------------------------------------------------------------------------------------") << endl;
		cout << c("                                                    ,--,                                      ") << endl;
	    cout << c("                                                 ,---.'|                                      ") << endl;
	    cout << c("   ,---,            ,---,                 ,---,. |   | :            ,-.----.        ,---,     ") << endl;
	    cout << c("  '  .' \\         .'  .' `\\             ,'  .' | :   : |            \\    /  \\     .'  .' `\\   ") << endl;
	    cout << c(" /  ;    '.     ,---.'     \\          ,---.'   | |   ' :            ;   :    \\  ,---.'     \\  ") << endl;
	    cout << c(":  :       \\    |   |  .`\\  |         |   |   .' ;   ; '            |   | .\\ :  |   |  .`\\  | ") << endl;
	    cout << c(":  |   /\\   \\   :   : |  '  |         :   :  |-, '   | |__          .   : |: |  :   : |  '  | ") << endl;
	    cout << c("|  :  ' ;.   :  |   ' '  ;  :         :   |  ;/| |   | :.'|         |   |  \\ :  |   ' '  ;  : ") << endl;
	    cout << c("|  |  ;/  \\   \\ '   | ;  .  |         |   :   .' '   :    ;         |   : .  /  '   | ;  .  | ") << endl;
	    cout << c("'  :  | \\  \\ ,' |   | :  |  '         |   |  |-, |   |  ./          ;   | |  \\  |   | :  |  ' ") << endl;
	    cout << c("|  |  '  '--'   '   : | /  ;          '   :  ;/| ;   : ;            |   | ;\\  \\ '   : | /  ;  ") << endl;
	    cout << c("|  :  :         |   | '` ,/           |   |    \\ |   ,/             :   ' | \\.' |   | '` ,/   ") << endl;
	    cout << c("|  | ,'         ;   :  .'             |   :   .' '---'              :   : :-'   ;   :  .'     ") << endl;
	    cout << c("`--''           |   ,.'               |   | ,'                      |   |.'     |   ,.'       ") << endl;
	    cout << c("                '---'                 `----'                        `---'       '---'         ") << endl;
	    cout << c("-----------------------------------------------------------------------------------------------------------------") << endls(3);
	    
	    cout << "		VITORIAS: " << Vict << endls(2); // <- endl * 2 un salto de linea por 2
	    
	    
	    cout << "		1. JUGAR!" << endl;
	    cout << "		2. SALIR" << endl;
		cout << "		3. INFO" << endls(2);
		
		cout << "		> ";
		
		cin >> I;
		
		switch(I){
			case 1:
				system("cls");
				Game();
			case 2:
				exit(0);
			case 3:
				system("cls");	
				cout << endl << endl;
				cout << c("Hola! Soy Angel JASG y eh creado esto porque estoy aburrido") << endl;
				cout << c("Libreria especial: JASG.h") << endl;
				cout << endl << "		Presiona SPACE para continuar!";
				needs("enter");
			default:
                system("cls");
                SoundInter(Musica_Effect_Error,Musica_Fondo,1000);
                msg("Eso no es una opcion", "error");
		}
	    
	}
}

void DERROTA(){
	system("cls");
	
	cout << endl << endl;
	cout << c("----------------------------------") << endl;
	cout << c("Lo sentimos perdiste :( ") << endl;
	cout << c("----------------------------------") << endl;
	SoundInter(Musica_Effect_Error,Musica_Fondo,1000);
	
	cout << endl << "		Presiona ENTER para continuar...";
	needs("enter");
	Menu();
}

void Victoria(){
	system("cls");
	SoundInter(Musica_Effect_Correct,Musica_Fondo,1000);
	cout << endl << endl;
	cout << c("----------------------------------") << endl;
	cout << c("FELICIDADES! GANASTE!!") << endl;
	cout << c("Victoria +1!") << endl;
	cout << c("----------------------------------") << endl;
	SoundInter(Musica_Effect_Win,Musica_Fondo,3000);
	Vict += 1;
	
	
	cout << endl << "		Presiona SPACE para continuar!";
	needs("space");
	Menu();
	

}

int GeN(int dificulty) {
    srand(static_cast<unsigned int>(time(0)));
    
    switch (dificulty) {
        case 1:
            NR = rand() % 10;
            Vidas = 3;
            DF = "Facil";
            break;
        case 2:
            NR = rand() % 100;
            Vidas = 10;
            DF = "Intermedio";
            break;
        case 3:
            NR = rand() % 1000;
            Vidas = 30;
            DF = "Imposible";
            break;
        default:
            cout << "ERROR: Numero de dificultad no esta en el rango." << endl;
            cout << "Se pone en modo facil";
            DF = "Facil";
            Sleep(1000);
            NR = rand() % 10;
            Vidas = 3;
            break;
    }
    return NR;
}

